import { ActivityHandler, ConversationState, StatePropertyAccessor, TurnContext, UserState } from 'botbuilder';
import { DialogContext, DialogSet } from 'botbuilder-dialogs';
import { CustomBotInterface } from './configs/interfacess';
import { LuisService } from './services/luis_service';
import { QnamakerService } from './services/qnamaker_service';
export declare class LavaBot extends ActivityHandler implements CustomBotInterface {
    private userState;
    private conversationState;
    private dialogState;
    private dialogSet;
    dialogContext: DialogContext;
    luisService: LuisService;
    qnamakerService: QnamakerService;
    constructor(userState: UserState, conversationState: ConversationState, dialogState: StatePropertyAccessor, dialogSet: DialogSet);
    run(context: TurnContext): Promise<void>;
}
