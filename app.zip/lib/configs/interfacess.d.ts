import { StatePropertyAccessor, TurnContext } from "botbuilder";
import { DialogContext, WaterfallStepContext } from "botbuilder-dialogs";
interface CustomDialogInterface {
    beginStep(stepContext: WaterfallStepContext): any;
    endStep(stepContext: WaterfallStepContext): any;
    run(turnContext: TurnContext, accessor: StatePropertyAccessor): any;
}
interface CustomBotInterface {
    dialogContext: DialogContext;
    run(context: TurnContext): Promise<void>;
}
export { CustomDialogInterface, CustomBotInterface };
