import { Middleware, StatePropertyAccessor, TurnContext } from "botbuilder";
import { DialogContext, DialogSet } from "botbuilder-dialogs";
declare class LogMiddleware implements Middleware {
    private dialogState;
    private dialogSet;
    dialogContext: DialogContext;
    constructor(dialogState: StatePropertyAccessor, dialogSet: DialogSet);
    onTurn(context: TurnContext, next: () => Promise<void>): Promise<void>;
}
export default LogMiddleware;
