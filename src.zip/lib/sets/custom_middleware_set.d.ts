import { MiddlewareSet, StatePropertyAccessor } from "botbuilder";
import { DialogSet } from "botbuilder-dialogs";
declare class CustomMiddlewareSet {
    private dialogState;
    private dialogSet;
    constructor(dialogState: StatePropertyAccessor, dialogSet: DialogSet);
    init(): MiddlewareSet;
}
export default CustomMiddlewareSet;
