import { StatePropertyAccessor } from "botbuilder";
import { ComponentDialog, WaterfallStepContext } from "botbuilder-dialogs";
import { CustomDialogInterface } from "../configs/interfacess";
import { Dialog } from "../configs/typess";
declare const ExitDialogId = "ExitDialogId";
declare class ExitDialog extends ComponentDialog implements CustomDialogInterface {
    private dialogState;
    constructor(dialogState: StatePropertyAccessor<Dialog>);
    beginStep(stepContext: WaterfallStepContext): Promise<import("botframework-schema").ResourceResponse>;
    endStep(stepContext: WaterfallStepContext): Promise<import("botbuilder-dialogs").DialogTurnResult<any>>;
    run(turnContext: any, accessor: any): Promise<void>;
}
export { ExitDialogId, ExitDialog };
