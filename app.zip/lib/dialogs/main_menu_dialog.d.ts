import { StatePropertyAccessor, TurnContext } from "botbuilder";
import { ComponentDialog, WaterfallStepContext } from "botbuilder-dialogs";
import { CustomDialogInterface } from "../configs/interfacess";
import { Dialog } from "../configs/typess";
declare const MainMenuDialogId = "MainMenuDialogId";
declare class MainMenuDialog extends ComponentDialog implements CustomDialogInterface {
    private dialogState;
    constructor(dialogState: StatePropertyAccessor<Dialog>);
    beginStep(stepContext: WaterfallStepContext): Promise<import("botbuilder-dialogs").DialogTurnResult<any>>;
    endStep(stepContext: WaterfallStepContext): Promise<import("botbuilder-dialogs").DialogTurnResult<any>>;
    run(turnContext: TurnContext, accessor: StatePropertyAccessor): Promise<void>;
}
export { MainMenuDialogId, MainMenuDialog };
