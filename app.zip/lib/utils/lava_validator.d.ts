import { PromptValidatorContext } from "botbuilder-dialogs";
export default class LavaValidator {
    static emailValidator(promptContext: PromptValidatorContext<String>): Promise<boolean>;
}
