import { TurnContext } from "botbuilder";
declare class QnamakerService {
    private qnaMaker;
    constructor();
    getAnswers(context: TurnContext): Promise<string>;
}
export { QnamakerService };
