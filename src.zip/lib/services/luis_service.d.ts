import { RecognizerResult, TurnContext } from "botbuilder";
declare class LuisService {
    private dispatchRecognizer;
    constructor();
    result(context: TurnContext): Promise<RecognizerResult>;
    topIntent(context: TurnContext): Promise<string>;
}
export { LuisService };
