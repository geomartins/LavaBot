import { StatePropertyAccessor } from "botbuilder";
import { DialogSet } from "botbuilder-dialogs";
declare class CustomDialogSet {
    private dialogState;
    dialogSet: any;
    constructor(dialogState: StatePropertyAccessor);
    init(): DialogSet;
}
export { CustomDialogSet };
