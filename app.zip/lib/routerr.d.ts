import { TurnContext } from "botbuilder";
import { DialogContext, DialogSet } from "botbuilder-dialogs";
declare class Routerr {
    private dialogContext;
    private dialogSet;
    constructor(dialogContext: DialogContext, dialogSet: DialogSet);
    run(context: TurnContext): Promise<void>;
    private efficientRoute;
}
export default Routerr;
