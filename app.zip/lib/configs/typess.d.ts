import { DialogContext } from "botbuilder-dialogs";
declare type MiddlewareData = {
    isAuthenticated?: boolean;
    isTerminated?: boolean;
};
declare type Dialog = {
    isDialogComplete?: boolean;
    name?: string;
    isWelcome?: boolean;
    menu?: string;
    email?: String;
    status?: "start" | "progress" | "end";
    dc?: DialogContext;
};
export { Dialog, MiddlewareData };
